/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//series problem//
//1+2^2/2! + 3^3/3! +..........+n//
#include <stdio.h>

int main()
{
    int i,n,fact=1,s=0;
    int nr=1;
    double sum=0.0;
    printf("enter the value of n:");
    scanf("%d",&n);
    for(i=1;i<=n;i+=2)
    {
        for(int j=1;j<=i;j++)
        {
            fact=fact*i;
        }
            for(int j=1;j<=i;j++)
            {
                nr*=j;
            }
            sum+=(double)nr/fact;
    
    }
    printf("%.6f",sum);
    return 0;
}
